/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */

package org.apache.commons.cli;

/**
 * OptionBuilder allows the user to create Options using descriptive methods.
 * <p>
 * Details on the Builder pattern can be found at
 * <a href="https://c2.com/cgi-bin/wiki?BuilderPattern">https://c2.com/cgi-bin/wiki?BuilderPattern</a>.
 * <p>
 * This class is NOT thread safe. See <a href="https://issues.apache.org/jira/browse/CLI-209">CLI-209</a>
 *
 * @since 1.0
 * @deprecated Since 1.3, use {@link Option#builder(String)} instead.
 */
@Deprecated
public final class OptionBuilder {

    /** Long option. */
    private static String longOption;

    /** Option description. */
    private static String description;

    /** Argument name. */
    private static String argName;

    /** Required test. */
    private static boolean required;

    /** The number of arguments. */
    private static int argCount = Option.UNINITIALIZED;

    /** Option type. */
    private static Class<?> type;

    /** Option can have an optional argument value. */
    private static boolean optionalArg;

    /** Value separator for argument value. */
    private static char valueSeparator;

    /** Option builder instance. */
    private static final OptionBuilder INSTANCE = new OptionBuilder();

    static {
        // ensure the consistency of the initial values.
        reset();
    }

    /**
     * Creates an Option using the current settings.
     *
     * @return The Option instance.
     * @throws IllegalArgumentException if {@code longOpt} has not been set.
     */
    public static Option create() throws IllegalArgumentException {
        if (longOption == null) {
            reset();
            throw new IllegalStateException("longopt missing");
        }
        return create(null);
    }

    /**
     * Creates an Option using the current settings and with the specified Option {@code char}.
     *
     * @param opt The character representation of the Option.
     * @return The Option instance.
     * @throws IllegalArgumentException if {@code opt} is not a valid character. See Option.
     */
    public static Option create(final char opt) throws IllegalArgumentException {
        return create(String.valueOf(opt));
    }

    /**
     * Creates an Option using the current settings and with the specified Option {@code char}.
     *
     * @param opt The {@code String} representation of the Option.
     * @return The Option instance.
     * @throws IllegalArgumentException if {@code opt} is not a valid character. See Option.
     */
    public static Option create(final String opt) throws IllegalArgumentException {
        Option option;
        try {
            // create the option
            option = new Option(opt, description);
            // set the option properties
            option.setLongOpt(longOption);
            option.setRequired(required);
            option.setOptionalArg(optionalArg);
            option.setArgs(argCount);
            option.setType(type);
            option.setConverter(TypeHandler.getDefault().getConverter(type));
            option.setValueSeparator(valueSeparator);
            option.setArgName(argName);
        } finally {
            // reset the OptionBuilder properties
            reset();
        }
        // return the Option instance
        return option;
    }

    /**
     * The next Option created will require an argument value.
     *
     * @return The OptionBuilder instance
     */
    public static OptionBuilder hasArg() {
        argCount = 1;
        return INSTANCE;
    }

    /**
     * The next Option created will require an argument value if {@code hasArg} is true.
     *
     * @param hasArg if true then the Option has an argument value.
     * @return The OptionBuilder instance.
     */
    public static OptionBuilder hasArg(final boolean hasArg) {
        argCount = hasArg ? 1 : Option.UNINITIALIZED;
        return INSTANCE;
    }

    /**
     * The next Option created can have unlimited argument values.
     *
     * @return The OptionBuilder instance.
     */
    public static OptionBuilder hasArgs() {
        argCount = Option.UNLIMITED_VALUES;
        return INSTANCE;
    }

    /**
     * The next Option created can have {@code num} argument values.
     *
     * @param num The number of args that the option can have.
     * @return The OptionBuilder instance.
     */
    public static OptionBuilder hasArgs(final int num) {
        argCount = num;
        return INSTANCE;
    }

    /**
     * The next Option can have an optional argument.
     *
     * @return The OptionBuilder instance.
     */
    public static OptionBuilder hasOptionalArg() {
        argCount = 1;
        optionalArg = true;
        return INSTANCE;
    }

    /**
     * The next Option can have an unlimited number of optional arguments.
     *
     * @return The OptionBuilder instance.
     */
    public static OptionBuilder hasOptionalArgs() {
        argCount = Option.UNLIMITED_VALUES;
        optionalArg = true;
        return INSTANCE;
    }

    /**
     * The next Option can have the specified number of optional arguments.
     *
     * @param numArgs   The maximum number of optional arguments the next Option created can have.
     * @return The OptionBuilder instance.
     */
    public static OptionBuilder hasOptionalArgs(final int numArgs) {
        argCount = numArgs;
        optionalArg = true;
        return INSTANCE;
    }

    /**
     * The next Option created will be required.
     *
     * @return The OptionBuilder instance.
     */
    public static OptionBuilder isRequired() {
        required = true;
        return INSTANCE;
    }

    /**
     * The next Option created will be required if {@code required} is true.
     *
     * @param newRequired if true then the Option is required.
     * @return The OptionBuilder instance.
     */
    public static OptionBuilder isRequired(final boolean newRequired) {
        required = newRequired;
        return INSTANCE;
    }

    /**
     * Resets the member variables to their default values.
     */
    private static void reset() {
        description = null;
        argName = null;
        longOption = null;
        type = String.class;
        required = false;
        argCount = Option.UNINITIALIZED;
        optionalArg = false;
        valueSeparator = (char) 0;
    }

    /**
     * The next Option created will have the specified argument value name.
     *
     * @param name The name for the argument value.
     * @return The OptionBuilder instance.
     */
    public static OptionBuilder withArgName(final String name) {
        argName = name;
        return INSTANCE;
    }

    /**
     * The next Option created will have the specified description
     *
     * @param newDescription A description of the Option's purpose.
     * @return The OptionBuilder instance.
     */
    public static OptionBuilder withDescription(final String newDescription) {
        description = newDescription;
        return INSTANCE;
    }

    /**
     * The next Option created will have the following long option value.
     *
     * @param newLongopt The long option value.
     * @return The OptionBuilder instance.
     */
    public static OptionBuilder withLongOpt(final String newLongopt) {
        longOption = newLongopt;
        return INSTANCE;
    }

    /**
     * The next Option created will have a value that will be an instance of {@code type}.
     *
     * @param newType The type of the Options argument value.
     * @return The OptionBuilder instance.
     * @since 1.3
     */
    public static OptionBuilder withType(final Class<?> newType) {
        type = newType;
        return INSTANCE;
    }

    /**
     * The next Option created will have a value that will be an instance of {@code type}.
     * <p>
     * <strong>Note:</strong> this method is kept for binary compatibility and the input type is supposed to be a {@link Class}
     * object.
     *
     * @param newType The type of the Options argument value.
     * @return The OptionBuilder instance.
     * @deprecated Since 1.3, use {@link #withType(Class)} instead.
     */
    @Deprecated
    public static OptionBuilder withType(final Object newType) {
        return withType((Class<?>) newType);
    }

    /**
     * The next Option created uses '{@code =}' as a means to separate argument values.
     *
     * <strong>Example:</strong>
     *
     * <pre>
     * Option opt = withValueSeparator().create('D');
     *
     * CommandLine line = parser.parse(args);
     * String propertyName = opt.getValue(0);
     * String propertyValue = opt.getValue(1);
     * </pre>
     *
     * @return The OptionBuilder instance.
     */
    public static OptionBuilder withValueSeparator() {
        valueSeparator = Char.EQUAL;
        return INSTANCE;
    }

    /**
     * The next Option created uses {@code sep} as a means to separate argument values.
     * <p>
     * <strong>Example:</strong>
     *
     * <pre>
     * Option opt = OptionBuilder.withValueSeparator('=').create('D');
     *
     * String args = "-Dkey=value";
     * CommandLine line = parser.parse(args);
     * String propertyName = opt.getValue(0); // will be "key"
     * String propertyValue = opt.getValue(1); // will be "value"
     * </pre>
     *
     * @param sep The value separator to be used for the argument values.
     * @return The OptionBuilder instance.
     */
    public static OptionBuilder withValueSeparator(final char sep) {
        valueSeparator = sep;
        return INSTANCE;
    }

    /**
     * private constructor to prevent instances being created.
     */
    private OptionBuilder() {
        // hide the constructor
    }
}
