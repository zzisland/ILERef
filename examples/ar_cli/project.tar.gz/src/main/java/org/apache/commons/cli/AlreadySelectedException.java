/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */

package org.apache.commons.cli;

/**
 * Thrown when more than one option in an option group has been provided.
 */
public class AlreadySelectedException extends ParseException {

    /**
     * This exception {@code serialVersionUID}.
     */
    private static final long serialVersionUID = 3674381532418544760L;

    /** The option group selected. */
    private final OptionGroup optionGroup;

    /** The option that triggered the exception. */
    private final Option option;

    /**
     * Constructs a new {@code AlreadySelectedException} for the specified option group.
     *
     * @param optionGroup The option group already selected.
     * @param option The option that triggered the exception.
     * @since 1.2
     */
    public AlreadySelectedException(final OptionGroup optionGroup, final Option option) {
        this(String.format("The option '%s' was specified but an option from this group has already been selected: '%s'", option.getKey(),
                optionGroup.getSelected()), optionGroup, option);
    }

    /**
     * Constructs a new {@code AlreadySelectedException} with the specified detail message.
     *
     * @param message The detail message.
     */
    public AlreadySelectedException(final String message) {
        this(message, null, null);
    }

    private AlreadySelectedException(final String message, final OptionGroup optionGroup, final Option option) {
        super(message);
        this.optionGroup = optionGroup;
        this.option = option;
    }

    /**
     * Gets the option that was added to the group and triggered the exception.
     *
     * @return The related option.
     * @since 1.2
     */
    public Option getOption() {
        return option;
    }

    /**
     * Gets the option group where another option has been selected.
     *
     * @return The related option group.
     * @since 1.2
     */
    public OptionGroup getOptionGroup() {
        return optionGroup;
    }
}
